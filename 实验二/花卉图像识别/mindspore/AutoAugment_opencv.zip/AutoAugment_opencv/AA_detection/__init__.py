
from .autoaugment_detection import PolicyV0, PolicyV1, PolicyV2, PolicyV3
